import turtle  
import pygame
from running_man import Running_man
from barraiers import barriers
#hide turtle
turtle.ht()
turtle.tracer(1)
#score
score = 0
#screen width, height
screen = turtle.getscreen()
SCREEN_WIDTH = turtle.getcanvas().winfo_width()/2 # here we get canvas(screen) width
SCREEN_HEIGHT = turtle.getcanvas().winfo_height()/2 # here we get the canvas(screen) height
#to keep screen 
turtle.tracer(1)
#descripe class
running_man1 = Running_man(0 ,-SCREEN_HEIGHT, 0, 0)
barriers1= barriers(100,-271,0,0)
barriers2= barriers(700,-271,0,0)
barriers3= barriers(1200,-271,0,0)
#add image,bg 
screen.bgpic("fans.gif")
turtle.addshape("man.gif")
turtle.addshape("5.gif")
#collide 
def collide(boxA, boxB):
	if(boxA.top_side() >= boxB.bottom_side() and
		boxA.right_side() >= boxB.left_side() and
		boxA.bottom_side() <= boxB.top_side() and
		boxA.left_side() <= boxB.right_side()):
		return True
	else:
		return False
#make the man jump
def upKeyPressed():
	if running_man1.dy == 0:
		running_man1.dy+=18
screen.onkey(upKeyPressed, "Up")
screen.listen()
#to make the turtle have a shape
running_man1.shape("man.gif")
barriers1.shape("5.gif")
barriers2.shape("5.gif")
barriers3.shape("5.gif")

while True :
	score= score+1
	#print score
	running_man1.move(-SCREEN_HEIGHT)
	barriers1.move(-SCREEN_HEIGHT)
	barriers2.move(-SCREEN_HEIGHT)
	barriers3.move(-SCREEN_HEIGHT)
	if (collide(running_man1,barriers1) or collide(running_man1,barriers2) or collide(running_man1,barriers3)):
		score = 0
		barriers1.init(SCREEN_HEIGHT,SCREEN_WIDTH)
		barriers2.init(SCREEN_HEIGHT,SCREEN_WIDTH+600)
		barriers3.init(SCREEN_HEIGHT,SCREEN_WIDTH+1200)
	screen.update()
	if barriers1.xcor <= -SCREEN_WIDTH:
		print"hello"

print (score)