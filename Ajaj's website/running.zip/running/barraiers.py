from turtle import Turtle
class barriers(Turtle):
	x = 0
	dy = 0
	width = 100
	height = 0

	def __init__(self, x, y, dx, dy):
		Turtle.__init__(self)
		self.pu()
		self.goto(x, y)
		self.dx = dx
		self.dy = dy
		self.shape("square")

	def move(self,SCREEN_HEIGHT):
		oldx = self.xcor()
		newx = oldx + self.dx
		self.goto(newx-10,SCREEN_HEIGHT/2 - 130)

	def init(self,SCREEN_HEIGHT, SCREEN_WIDTH):
		self.goto(SCREEN_WIDTH,SCREEN_HEIGHT/2 - 130)

	def left_side(self):
		return self.xcor()-(self.width/2)
	def right_side(self):
		return self.xcor()+(self.width/2)
	def top_side(self):
		return self.ycor()+(self.height/2)
	def bottom_side(self):
		return self.ycor()-(self.height/2)
