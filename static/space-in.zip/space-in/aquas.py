import palgame
import pygame
import math
import random
from threading import Timer
picture = pygame.image.load("space.jpg")
picture = pygame.transform.scale(picture, (1300, 700))


SCREEN_WIDTH = 1300
SCREEN_HEIGHT = 700

shot_fired = False
shooter_movement_x = 10
shooter_x = 100
shooter_y = 655
shooter_width = 100
shooter_height = 30

circle_rad = 5
circle_y = shooter_y

movementx = 5
movementy = 10
GREEN1 = (178, 255, 102)
GREEN2 = (153,255,51)
GREEN = (0, 255, 0)
GREEN4 = (0, 204, 0)
GREEN5 = (0, 153, 0)
GREEN6 = (76, 153, 0)
BLUE_shooter = (51, 51, 255)
BLUE = (0, 0, 255)
RED = (255, 0, 0)

NUM_BRICK_COL = 10
NUM_BRICK_ROW = 6

colors = [GREEN1, GREEN2, GREEN, GREEN4, GREEN5,GREEN6]
screen = palgame.build_screen(SCREEN_WIDTH, SCREEN_HEIGHT)

bricks = []
# one_brick = [x, y, width, height]
blocks = []
# one_brick = [x, y, width, height]

brick_width = 70
brick_height = 20
block_width = 100
block_height = 40



# creates all the bricks
for row in range(NUM_BRICK_ROW):
	for col in range(NUM_BRICK_COL):
		brick_x = 100 + col*100
		brick_y = 100 + row*30
		bricks.append([brick_x, brick_y])

circle_x = 0
circle_movement_y = 0


def move_on_key_press(key_code, movement):
	if pygame.key.get_pressed()[key_code]:
		return movement
	else:
		return 0
Remaining_bricks= NUM_BRICK_ROW*NUM_BRICK_COL
myfont = pygame.font.SysFont("purisa",35)
myfont1 = pygame.font.SysFont("purisa",50)
count = 0
bricks_y_move = 0
while True:
	#create timer
	time = palgame.get_event()
	count = count +time
	bricks_y_move += time
	if count >= 180000:
		break
	
	# go down every 10 secs
	if bricks_y_move >= 10000:
		for i in range (0, brick_count):
			brick = bricks [i]
			if brick == False:
				continue
			brick_y = brick [1] + movementy
			bricks[i] = [brick[0],brick_y]
		bricks_y_move = 0
	
	palgame.clear_screen()
	screen.blit(picture, (0,0))

	shooter_x += move_on_key_press(pygame.K_RIGHT, shooter_movement_x)
	shooter_x += move_on_key_press(pygame.K_LEFT, -1*shooter_movement_x)
	shooter_x = shooter_x%1300

	# can shoot bullet 
	if pygame.key.get_pressed()[pygame.K_SPACE] == True and shot_fired == False:
		shot_fired = True
		circle_x = shooter_x + shooter_width/2
		circle_movement_y = 10		
	# reset the amunition
	if circle_y < 0:
		shot_fired = False
		circle_movement_y = 0
		circle_y = shooter_y
	# loop through the bricks
	brick_count = len(bricks)
	biggest_x = 0
	smallest_x = 100
	for i in range(0, brick_count):
		brick = bricks[i]
		if brick == False:
			continue
		brick_x = brick[0] + movementx
		brick_y = brick[1] 
		if brick_x > biggest_x:
			biggest_x = brick_x
		if brick_x < smallest_x:
			smallest_x = brick_x
		# set the x, y of the brick
		bricks[i] = [brick_x, brick_y]
	if biggest_x+ brick_width >=1300:
		movementx = -5
	if smallest_x <=0:
		movementx = 5
	circle_y -= circle_movement_y
	# loop through the bricks
	brick_count = len(bricks)
	for i in range(0, brick_count):
		brick = bricks [i]
		if brick == False:
			continue
		brick_x = brick[0]
		brick_y = brick[1] 
		# check collision with bullet
		if circle_x >= brick_x and circle_x <= brick_x + brick_width and circle_y >= brick_y and circle_y<= brick_y +brick_height:
			circle_y = -500
			circle_x = -1
			shot_fired = False
			brick = False
			bricks [i] = brick
			Remaining_bricks=Remaining_bricks-1
	# draw everything
	brick_count = len(bricks)
	for i in range(0, brick_count):
		brick = bricks[i]
		if brick == False:
			continue
		brick_x = brick[0]
		brick_y = brick[1]

		palgame.draw_rect(brick_x, brick_y, brick_width, brick_height, colors[i % NUM_BRICK_ROW])
	palgame.draw_rect(shooter_x, shooter_y, shooter_width, shooter_height, BLUE_shooter)

	score_label = myfont.render("remaining bricks = " + str(Remaining_bricks), 1, GREEN)
	screen.blit(score_label, (0, 0))
	Time_remaining = (NUM_BRICK_ROW*NUM_BRICK_COL*3)-count/1000
	score_label = myfont.render("Time Remaining= " + str(Time_remaining), 1, GREEN)
	screen.blit(score_label, (940, 0))

	if Remaining_bricks ==0 :
		palgame.clear_screen()
		score_label = myfont1.render("You Win", 1, GREEN)
		screen.blit(score_label, (530, 270))

	if Remaining_bricks ==0 :
		score_label = myfont1.render("WE CODE", 1, RED)
		screen.blit(score_label, (30, 30))

	if Remaining_bricks ==0 :
		score_label = myfont1.render("Design by : Ibraheem ajaj, Omar Khatib", 1, (255, 255, 255))
		screen.blit(score_label, (530, 500))

	if shot_fired:
		palgame.draw_circle(circle_x, circle_y, circle_rad, GREEN)
	palgame.draw_everything()